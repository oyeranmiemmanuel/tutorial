# CS50 fan club website
#### Video Demo: https://youtu.be/H1ZHKWupmd0
#### Description: 
this is a website that allows student to show case their thougth by creating a post. This happens by aloowing 
them to create an account on it and post any of their desire content. Also allowing other users to comment on each post. post Owner can  edit and delete their post at preferable time. It  is user friendly and simple.. 