from flask import Flask, render_template



app= Flask(__name__)
# app.config['SQLALCHEMY_DATABASE_URI']= "mysql+pymysql://root:Emmanuel#5336@localhost:3306/Users"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///Users.db'  # Replace with your actual database URI
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY']='randomtext'
app.config['UPLOAD_FOLDER'] = 'uploads'
# db= SQLAlchemy(app)


from website import route
