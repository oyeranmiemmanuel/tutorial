from flask_wtf import FlaskForm as Form
from wtforms import StringField, TextAreaField, PasswordField
from wtforms.validators import DataRequired, Length, EqualTo, URL, ValidationError
from wtforms import StringField, PasswordField, SubmitField, BooleanField, RadioField, SelectField
from wtforms import EmailField
# from flask_wtf import RecaptchaField
from website.models import User
from flask_wtf.file import FileField, FileAllowed
import os 
from werkzeug.security import check_password_hash
from flask import session


user=User()


class CommentForm(Form):
    text = TextAreaField(u'Comment', validators=[DataRequired()])


class PostForm(Form):
    title = StringField('Title', [
        DataRequired(),
        Length(max=255)
    ])
    text = TextAreaField('Content', [DataRequired()])
    image = FileField('Choose an Image', validators=[FileAllowed(['jpg', 'jpeg', 'png', 'gif'])])


class RegisterForm(Form):
    first_name = StringField('First Name', validators=[DataRequired(message="Please enter your first name.")])
    last_name = StringField('Last Name', validators=[DataRequired(message="Please enter your last name.")])
    email = EmailField('Email', validators=[DataRequired(message="Please enter your email address.")])
    username = StringField('Username', validators=[DataRequired(message="Please enter a username.")])
    password = PasswordField('Password', validators=[DataRequired(message="Please enter a password.")])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(message="Please confirm your password."), EqualTo('password', message="Passwords must match.")])
    course_taken = StringField('Course Taken', validators=[DataRequired(message="Please enter the course you've taken.")])
    gender = RadioField('Gender', choices=[('male', 'Male'), ('female', 'Female')], validators=[DataRequired(message="Please select your gender.")])
    year_joined = SelectField('Year Joined', choices=[('2020', '2020'), ('2021', '2021'), ('2022', '2022'), ('2023', '2023')], validators=[DataRequired(message="Please select the year you joined.")])
    country = StringField('Country', validators=[DataRequired(message="please specify your country.")])
    image = FileField('Choose an Image', validators=[FileAllowed(['jpg', 'jpeg', 'png', 'gif'])])
    


    def validate_username(self, username):
        cur_user = user.check_user(username = username.data)

        # Is the username already being used
        if cur_user:
            username.errors.append("User with that name already exists")



    # def validate_email(self, email):
    #     cur_email = user.check_user(email=email)
    #     print(len(cur_email))
    #     if len(cur_email) > 0:
    #         email.errors.append("Email already exists")



class LoginForm(Form):
    username = StringField('Username', validators=[DataRequired(message="Please enter your Username")])
    password = PasswordField('Password', validators=[DataRequired(message="Please enter your password")])
    remember = BooleanField("Remember Me")



class ChangePassword(Form):
    current_password = PasswordField('Current Password', validators=[DataRequired(message="Please enter your current password.")])
    password = PasswordField('Password', validators=[DataRequired(message="Please enter a password.")])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(message="Please confirm your password."), EqualTo('password', message="Passwords must match.")])

    def validate_password(self, current_password):
        user_password = user.check_password(current_password.data, session['user_id'])
        if user_password is False:
            current_password.errors.append("Current password incorrect")
            # raise ValidationError("Old password incorrect")

class UpdateUser(Form):
    first_name = StringField('First Name', validators=[DataRequired(message="Please enter your first name.")])
    last_name = StringField('Last Name', validators=[DataRequired(message="Please enter your last name.")])
    email = EmailField('Email', validators=[DataRequired(message="Please enter your email address.")])
    username = StringField('Username', validators=[DataRequired(message="Please enter a username.")])
    course_taken = StringField('Course Taken', validators=[DataRequired(message="Please enter the course you've taken.")])
    gender = RadioField('Gender', choices=[('male', 'Male'), ('female', 'Female')], validators=[DataRequired(message="Please select your gender.")])
    year_joined = SelectField('Year Joined', choices=[('2020', '2020'), ('2021', '2021'), ('2022', '2022')], validators=[DataRequired(message="Please select the year you joined.")])
    country = StringField('Country', validators=[DataRequired(message="please specify your country.")])
    image = FileField('Choose an Image', validators=[FileAllowed(['jpg', 'jpeg', 'png', 'gif'])])
    
