from cs50 import SQL
from werkzeug.security import check_password_hash


# db = SQL("mysql://username:password@host:port/database")

db = SQL("mysql://root:Emmanuel#5336@localhost:3306/Users")

class User:
	def __init__(self):
		db.execute("USE Users")
		# self.rows = db.execute("SHOW TABLES")

	def create_user(self, first_name, last_name, email, username, password, course_taken, gender, year_joined, country, user_image):
		# try:
		user = db.execute("INSERT INTO user (first_name, last_name, email, username, password, course_taken, gender, year_joined, country, user_image) \
						VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",first_name, last_name, email, username, password, course_taken, gender, year_joined, country, user_image)
		
		return user 
		# except:
		# 	return None


	def update_user(self, first_name, last_name, email, username, course_taken, gender, year_joined, country, user_image=None, id=None):

		# print(username)
		# try:
		if user_image:
			# user = db.execute("UPDATE user SET first_name=?,last_name=?, email=?, username=?, course_taken =?, gender=?, year_joined=?, country=?, user_image=? WHERE id = ?", 
			# 			first_name, last_name, email, usernaname, course_taken, gender, year_joined, country, user_image, id)
			user = db.execute("UPDATE user SET first_name= :first_name, last_name= :last_name, email= :email , username= :username, \
				course_taken = :course_taken, gender= :gender, year_joined= :year_joined, country= :country, user_image= :user_image WHERE id = :id", 
						first_name=first_name, last_name=last_name, email=email, username=username, course_taken=course_taken, gender=gender,\
						 year_joined=year_joined, country=country, user_image=user_image, id=id)

		else:
			# user = db.execute("UPDATE user SET first_name=?, last_name=?, email=?, username=?, course_taken =?, gender=?, year_joined=?, country=?, WHERE id = ?", 
			# 			first_name, last_name, email, username, course_taken, gender, year_joined, country, id)
			user = db.execute("UPDATE user SET first_name= :first_name, last_name= :last_name, email= :email , username= :username, \
				course_taken = :course_taken, gender= :gender, year_joined= :year_joined, country= :country WHERE id = :id", 
						first_name=first_name, last_name=last_name, email=email, username=username, course_taken=course_taken, gender=gender,\
						 year_joined=year_joined, country=country, id=id)

			return user
		# except:
		# 	return None

	def check_user(self, username=None, user_id=None, email=None):
		try:
			if username:
				user = db.execute("SELECT * FROM user WHERE username= :username", username=username)
				return user

			if user_id:
				user = db.execute("SELECT * FROM user WHERE id= :id", id=user_id)
				return user

			if email:
				user = db.execute("SELECT * FROM user WHERE email= :email", email=email)
				return user
		except:
			return None


	def check_password(self, c_password, id):
		try:
			user = db.execute("SELECT password FROM user WHERE id= :id", id=id)
			return check_password_hash(user[0]['password'], c_password)
		except:
			return None

	def update_password(self, id, password):
		user = db.execute("UPDATE user SET password = :password WHERE id = :id", password=password, id=id)
		return user

	def get_all_user(self):
		try:
			users = db.execute("SELECT * FROM user")
			return user 

		except:
			return None

class Post:
	def __init__(self):
		db.execute("USE Users")

	def create_post(self, title, p_texts, user_id, post_image):
		try:
			post = db.execute("INSERT INTO post (title, p_texts, user_id, post_image) \
							VALUES(?, ?, ?, ?)", title, p_texts, user_id, post_image)

			return post


		except:
			return None

	def edit_post(self, title, p_texts, user_id, post_image):
		# try: 
		post = db.execute("UPDATE post SET title = :title, p_texts = :p_texts, post_image = :post_image WHERE user_id = :user_id", 
					title=title, p_texts=p_texts, post_image=post_image, user_id=user_id)
		return post

		# except:
		# 	return None 



	def get_post_by_user_id(self, user_id = None, username=None):
		try:
			if user_id:
				posts = db.execute("SELECT * FROM post WHERE user_id = :user_id", user_id = user_id)
				return posts

			if username:
				posts = db.execute("SELECT * FROM post WHERE user_id = (SELECT id FROM user where username= :username)", username = username)
				return posts

			posts = db.execute("SELECT * FROM post")

			return posts

		except:
			return None

	def get_post_by_id(self, post_id):
		try:
			post = db.execute("SELECT * FROM post WHERE id = :post_id", post_id=post_id)
			return post

		except:
			return None

	def get_post_id(self, post_id):
		try:
			if post_id:
				post = db.execute("SELECT user_id FROM post WHERE id = :post_id", post_id=post_id)
				return post 

		except:
			return None

	def deletePost(self, post_id):
		try:
			delete = db.execute("DELETE FROM post WHERE id=:post_id", post_id=post_id)
			return delete

		except:
			return None


	def fetch_post(self, page, post_par_page):
		try: 
			offset = (page-1) * post_par_page
			posts = db.execute("SELECT * FROM post ORDER BY id DESC LIMIT (?) OFFSET (?)", post_par_page, offset)
			return posts
		except:
			return None
		 
		


class Comment:
	def __init__(self):
		db.execute("USE Users")

	def create_comment(self, name, c_text, post_id):

		comment = db.execute("INSERT INTO comment(name, c_text, post_id) \
			VALUES (?)", (name, c_text, post_id))

		return comment

	def get_comment(self, id):

		comment = db.execute("SELECT * FROM comment WHERE post_id = (SELECT id FROM post WHERE id= :id) \
				", id = id)

		return comment


user1 = User()
# print(user1.create_user(1, "Oyeranmi", "Emmanuel", "oyeranmie@gmail.com", "emmy" "emmanuel5336", "CS50", "male", 2023))
# print(user1.create_user("Oyeranmi", "Ope", "opay@gmail.com", "Opeey", "Abim", "CS50AI", "female", 2024))
# print(user1.update_user( "emmanuel5336", "CS50AI", "male", 2024))
# print(user1.check_user(user_id=1))

# print(user1.check_user(email="oyeranmip@gmail.com"))
# 	print("yes")

# else:
	# print("No")
# print(user1.check_password("emmy", 1))


post = Post()
# print(post.create_post("Second Post", "Second post on the site", 1))
# print(post.create_post("Third Post", "Third post on the site", 2))
# print(post.create_post("Forth Post", "Forth post on the site", 1))
# print(post.create_post("Fifth Post", "Fifth post on the site", 2))
# print(len(post.get_post_by_user_id(username='emmy')))
# print(post.create_post("Sixth Post", "Sixth post on the site", 1))

posts = post.get_post_by_user_id(username="emmy")
# print(posts)

comment = Comment()
# print(comment.create_comment("emmy", "Wow lovely post", 3))
# print(comment.create_comment("sammy", "Not bad for starting", 4)) 
# print(comment.create_comment("Sammy", "Is this available??", 5))

# print(comment.get_comment(3))