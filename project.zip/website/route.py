from flask import render_template, redirect, url_for, request
from flask import Flask, session, abort
from website import app
from website.forms import RegisterForm, LoginForm, PostForm, CommentForm, ChangePassword, UpdateUser
from website.models import User, Post, Comment, db 
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash
from flask_wtf.csrf import CSRFProtect
from website.helpers import login_required
import base64





app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)
csrf = CSRFProtect(app)


@app.errorhandler(404)
def page_not_found(error):
    return render_template('404.html'), 404


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response



@app.route("/register", methods=['GET', 'POST'])
def register():
	form = RegisterForm()
	if form.validate_on_submit():
		first_name = form.first_name.data
		last_name = form.last_name.data
		email = form.email.data
		username = form.username.data
		password = form.password.data
		confirm_password = form.confirm_password.data
		course_taken = form.course_taken.data
		gender = form.gender.data 
		year_joined = form.year_joined.data
		hashed = generate_password_hash(password)
		country = form.country.data
		user_image = form.image.data
		image_data = user_image.read()
		user = User()
		create_user = user.create_user(first_name, last_name, email, username, hashed,
        	course_taken, gender, year_joined, country, image_data) 

		return redirect(url_for('login'))
		# return "success"



		# print(first_name, last_name, email, username, password,
        #       confirm_password, course_taken, gender, year_joined)
		# # return redirect(url_for('.home'))
		# return "Success"
	else:
		return render_template('register.html', form=form)

        
      

@app.route("/")
def home():


	return render_template("index.html", session=session)


# @app.route("/sign-up")
# def create_acc():

# 	return render_template("sign-up.html")

@app.route("/login", methods=['POST', 'GET'])
def login():
	session.clear()
	form = LoginForm()
	if form.validate_on_submit():
		username = form.username.data
		password = form.password.data 

		db.execute("USE Users")
		user = User()
		user = user.check_user(username)
		if not user or not check_password_hash(user[0]["password"], password):
			return render_template("login.html", form=form, message = "Username or password incorrect")

		session["user_id"] = user[0]["id"]

		return redirect("/posts")

	return render_template("login.html", form=form)



@app.route("/logout")
def logout():

	session.clear()

	return redirect("/login")


@app.route("/about")
def about():

	return "About page"

# @app.route("/blogs")
# def blog():

# 	return render_template("blogs.html")


@app.route("/features")
def features():

	return "features page"


@app.route("/user-dashboard")
@login_required
def dashboard():
	user = User()
	posts = Post()
	user = user.check_user(user_id=session['user_id'])
	all_post_data = []
	if user:
		username = user[0]['username']
		for info in user:
			first_name = info['first_name']
			last_name = info['last_name']
			username = info['username']
			year = info['year_joined']
			course = info['course_taken']
			country = info['country']
			user_image = info['user_image']
			post = posts.get_post_by_user_id(user_id=session['user_id'])

			post_data = {
				'first_name' : first_name,
				'last_name' : last_name,
				'username' : username,
				'year_joined' : year,
				'course' : course  ,
				'country' : country,
				'user_image' : user_image,
				'post_length': len(post)
			}

			all_post_data.append(post_data)

	return render_template("dashboard.html", user=username, all_post_data=all_post_data, base64=base64)


@app.route("/posts")
@login_required
def get_all_posts():
	all_post_data = []
	post_model = Post()
	posts = post_model.get_post_by_user_id()
	users = User()
	user = users.check_user(user_id=session['user_id'])
	if user:
		user = user[0]['username']
	

		for post_dict in posts:
		    post_id = post_dict['id']
		    title = post_dict['title']
		    p_texts = post_dict['p_texts']
		    publish_date = post_dict['publish_date']
		    user_id = post_dict['user_id']
		    image = post_dict['post_image']
		    # Get comments for the current post
		    comments = Comment().get_comment(post_id)
		    total = len(comments)





		    post_data = {
		        'post_id': post_id,
		        'title': title,
		        'p_texts': p_texts,
		        'publish_date': publish_date,
		        'user_id': user_id,
		        'comments': total,
		        'image' : image,
		    }
		    post_user = users.check_user(user_id=post_data['user_id'])
		    post_user = post_user[0]['username']
		    post_data['post_user'] = post_user
		    all_post_data.append(post_data)


	return render_template("posts.html", all_post_data=all_post_data, 
				base64=base64, user=user)
	# return "User not found"



@app.route("/new", methods = ['GET', 'POST'])
@login_required
def new_post():
	form = PostForm()
	post = Post()
	if form.validate_on_submit():
		title = form.title.data 
		text = form.text.data 
		image_file = form.image.data

		image_data = image_file.read()

		user_id = session["user_id"] 
		new_post = post.create_post(title, text, user_id, image_data)
		if new_post:
			return redirect(url_for('.get_all_posts', post_id = user_id))

	return render_template('new_post.html', form=form)


@app.route("/user/<string:user_name>")
@login_required
def posts_by_user(user_name):
	print(user_name)
	all_post_data = []
	posts = Post()
	user = User()
	comment_model = Comment()
	posts = posts.get_post_by_user_id(username=user_name)
	userid= session['user_id']
	post_user = user.check_user(user_id=userid)
	post_user = post_user[0]['username']
	user_names = user.check_user(user_id=session['user_id'])[0]['username']

	# print(posts)
	
	if posts:
		for post_dict in posts:
			post_id = post_dict['id']
			title = post_dict['title']
			p_texts = post_dict['p_texts']
			publish_date = post_dict['publish_date']
			user_id = post_dict['user_id']
			image = post_dict['post_image']
			comments = comment_model.get_comment(post_id)


			post_data = {
			        'post_id': post_id,
			        'title': title,
			        'p_texts': p_texts,
			        'publish_date': publish_date,
			        'user_id': user_id,
			        'comments': len(comments),
			        'image': image
			    }

			# print(post_data['title'])
			all_post_data.append(post_data)


	return render_template("user_post.html", post_user=post_user, userid=userid, form=None, base64=base64, all_post_data=all_post_data, user=user_names)


@app.route("/edit-profile", methods=['POST', 'GET'])
@login_required
def edit_profile():
	user_id = session['user_id']
	users = User()
	user = users.check_user(user_id=user_id)
	all_details = {}
	post_data = []

	for items in user:
		all_details['first_name'] = items['username']
		all_details['last_name'] = items['last_name']
		all_details['email'] = items['email']
		all_details['username'] = items['username']
		all_details['course_taken'] = items['course_taken']
		all_details['year_joined'] = items['year_joined']
		all_details['country'] = items['country']
		all_details['gender'] = items['gender']
		all_details['user_image'] = items['user_image']

		post_data.append(all_details)

	form = UpdateUser(gender=all_details['gender'])
	if form.validate_on_submit():
		first_name = form.first_name.data
		last_name = form.last_name.data
		email = form.email.data
		username = form.username.data
		course_taken = form.course_taken.data
		gender = form.gender.data 
		year_joined = form.year_joined.data
		country = form.country.data
		user_image = form.image.data
		if user_image:
			image_data = user_image.read()
		else:
			image_data = None
		users.update_user(first_name, last_name, email, username, course_taken, gender,
					year_joined, country, image_data, session['user_id'])

		return redirect(url_for('dashboard'))



	p_update = ChangePassword()
	if p_update.validate_on_submit():
		password = p_update.confirm_password.data 
		users.update_password(session['user_id'], generate_password_hash(password))

		return redirect(url_for('dashboard'))



	return render_template("edit_profile.html", form=form, base64=base64, all_details=post_data, p_update=p_update)


@app.route('/post/<int:post_id>', methods=['GET', 'POST'])
@login_required
def post(post_id):
	all_post_data = []
	posts = Post()
	posts = posts.get_post_by_id(post_id)
	user=User()
	form = CommentForm()
	comment_model =  Comment()
	user_name = user.check_user(user_id=session['user_id'])[0]['username']
	posts_data= {}

	

	for post in posts:
		posts_data['title'] = post['title']
		posts_data['p_texts'] = post['p_texts']
		posts_data['publish_date'] = post['publish_date']
		posts_data['user_id'] = post['user_id']
		posts_data['post_image'] = post['post_image']

		post_user = user.check_user(user_id=posts_data['user_id'])
		post_user = post_user[0]['username']

		posts_data['post_user'] = post_user


		all_post_data.append(posts_data)

	t_comment = None

	commenter_image=None
	post_comment = comment_model.get_comment(post_id)
	if post_comment:
		t_comment = post_comment
		commenter_image = user.check_user(username=post_comment[0]['name'])[0]['user_image']
		# print(t_comment)



	if form.validate_on_submit():
		comment_text = form.text.data
		comment_name = user.check_user(user_id=session['user_id'])[0]['username']
		p_id = post_id 

		# print(comment_text, comment_name, p_id)

		comment = comment_model.create_comment(comment_name, comment_text, p_id)
		return redirect(url_for('.post', post_id=post_id))



	return render_template("single_post.html", base64=base64, form=form, all_post_data=all_post_data, comm=t_comment,
		commenter_image=commenter_image, user=user_name)



@app.route("/edit/<int:post_id>", methods=['POST', 'GET'])
@login_required
def edit_post(post_id):
	post = Post()
	user_id = session['user_id']
	post_id = post.get_post_id(post_id)
	
	user_post = post.get_post_by_user_id(user_id=user_id)
	form = PostForm()
	form.title.data = user_post[0]['title']
	form.text.data = user_post[0]['p_texts']
	image = user_post[0]['post_image']

	if form.validate_on_submit():
		title = form.title.data 
		text = form.text.data 
		image_file = form.image.data

		image_data = image_file.read() 
		# print(image_data)
		# print(text)
		
		new_image = post.edit_post(title, text, user_id, image_data)
		if new_image:
			return redirect(url_for('.get_all_posts', post_id = user_id))
			# return "Hello"




	return render_template('edit_post.html', form=form, image=image, base64=base64)
	# abort(403)

@app.route("/delete/<int:post_id>")
@login_required
def delete_post(post_id):
	user_id = session['user_id']
	post = Post()
	post_id = post.get_post_by_id(post_id)
	if post_id:
		post_ids= post_id[0]['id']
		delete = post.deletePost(post_ids)

		if delete:
			return redirect(url_for('.get_all_posts', post_id=user_id))

	return "post not found"