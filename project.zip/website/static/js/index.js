$(document).ready(function(){
	$("#indicate").click(function() {
		// body...
		$("#togg").slideToggle(500);
	});


})