$(function() {
    $(".navbar-toggler").on("click", function(e) {
        $(".tm-header").toggleClass("show");
        e.stopPropagation();
      });
    
      $("html").click(function(e) {
        var header = document.getElementById("tm-header");
    
        if (!header.contains(e.target)) {
          $(".tm-header").removeClass("show");
        }
      });
    
      $("#tm-nav .nav-link").click(function(e) {
        $(".tm-header").removeClass("show");
      });

  $("#searchInput").on("input", function() {
        // Get the search input value
        var searchTerm = $(this).val().toLowerCase();

        // Get the specific div you want to search within
        var specificDivContent = $("#div1").html().toLowerCase();
         $("#div1").empty();

        if (specificDivContent.includes(searchTerm)) {
            // Show the entire HTML content of the matched div
            $("#resultArea").html($("#div1").html());
        }

    });


});